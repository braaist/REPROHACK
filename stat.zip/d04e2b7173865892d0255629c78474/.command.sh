#!/usr/bin/env bash
Rscript /home/ubuntu/REPROHACK/stat.R out_count_tab.txt
